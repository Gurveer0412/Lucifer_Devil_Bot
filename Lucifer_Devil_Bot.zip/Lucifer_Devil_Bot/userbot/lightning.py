#kang krne aaye ho  chala ja bhosdike tere kaam ka ni h ye
#make by legendx22 for chutiapa 🤔😑 you dont kang this 
#okay to ab isme cheeze bharte h 
#if you read only this then okay else
#chala jaa bhosdike 
import os
from userbot import ALIVE_NAME 
MASTER = str(ALIVE_NAME) if ALIVE_NAME else "LIGHTNING"
NAME = os.environ.get("BOT_NICK_NAME")
BOT =  = str(NAME) if NAME else "BLACK LIGHTNING"
#op for keinshin

Keinshin = "[Guri Developer](https://t.me/ICGOwnerGuri)"
OP = "[Devil](https://github.com/Gurveer0412/Lucifer_Devil_Bot)"
OKAY = "[SUPPORT GROUP](https://t.me/reqandtake)"
#itna test h aur aage krte h
#test successful raha ab aage 
ALIVE = "Lucifer Devil BOT IS ON 🔥 FIRE 🔥" #make by LEGENDX22 for black lightning
USERBOT = " HELLO MASTER MY NAME IS Guri Developer BOT I AM A BEST USERBOT 💝"
EMOJI = "⚡"
#yrr isko apne bot me aply krne se pehle mere se pooch lena ok
#aur aage add kruga abhi busy okay 🤔
