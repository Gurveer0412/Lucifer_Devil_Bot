#Plugin By @Rishisuperyo
#Kang = ultra gey
#keep credits = cool coder :)
#usage :-.repo
#plz dont kang it take a lot of time to made🥺 plz Dont kang 🥺🥺
#, plz keep credits of Rishisuperyo 😎⚡
from telethon import events
from userbot.utils import lightning_cmd
from userbot import CMD_HELP
@borg.on(lightning_cmd(pattern=r"repo", outgoing=True))
async def hapy(event):
     a="𝙷𝙴𝚈 𝙷𝙴𝚁𝙴 𝙸𝚉 𝚃𝙷𝙴 𝙾𝙿 [⚡𝙱𝙻𝙰𝙲𝙺 𝙻𝙸𝙶𝙷𝚃𝙽𝙸𝙽𝙶 𝚁𝙴𝙿𝙾⚡](https://github.com/Keinshin/Black-Lightning)"
     await event.edit(a)
