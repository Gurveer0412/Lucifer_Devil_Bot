#Plugin By @Rishisuperyo
#Kang = ultra gey
#keep credits = cool coder😎
#usage :-.opp
#plz dint kang it take a lot of time to made😭
#, plz keep credits of Rishisuperyo ⚡
#Animation by kiddo😎
from telethon import events
from userbot.utils import lightning_cmd
from userbot import CMD_HELP
@borg.on(lightning_cmd(pattern=r"opp", outgoing=True))
async def hapy(event):

     a="░█▀▀▀█     ░█▀▀▀█\n░█──░█     ░█──░█\n░█──░█     ░█▀▀▀▀\n░█──░█     ░█\n░█▄▄▄█     ░█"
     await event.edit(a)
