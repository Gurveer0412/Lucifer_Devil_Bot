#plugun by Rishisuperyo
#kang = GEY
#KEEP CREDITS OF RISHISUPERYO
#usage .🥺plz
from telethon import events
import asyncio
from userbot.utils import lightning_cmd
from userbot import CMD_HELP
@borg.on(lightning_cmd(pattern=r"🥺plz", outgoing=True))
async def _(event):
     a="plz 🥺🙏🥺🙏🥺🙏🥺🙏🥺🙏🥺"
     await event.edit(a)
     await asyncio.sleep(1)
     b="plz 🙏🥺🙏🥺🙏🥺🙏🥺🙏🥺🙏"
     await event.edit(b)
     await asyncio.sleep(1)
     c="🥺🙏🥺🙏🥺🙏🥺🙏🥺🙏🥺🙏"
     await event.edit(c)
     await asyncio.sleep(1)
     d="plz 🥺🥺🥺bhaiya🥺🥺🥺"
     await event.edit(d)
     await asyncio.sleep(1)
     e="plz didi,bhaiya sabko bol raha plz🙏🥺🙏🥺🙏🥺🙏🥺🙏🥺🙏🥺🙏🥺"
     await event.edit (e)
     await asyncio.sleep(1)
     f="🥺🥺🥺           🥺            🥺🥺 🥺\
        \n🥺       🥺         🥺                    🥺\
        \n🥺 🥺🥺          🥺                  🥺\
        \n🥺                    🥺               🥺🥺🥺\
        \n🥺                    🥺\
        \n🥺                    🥺🥺🥺🥺🥺"
     await event.edit(f)
