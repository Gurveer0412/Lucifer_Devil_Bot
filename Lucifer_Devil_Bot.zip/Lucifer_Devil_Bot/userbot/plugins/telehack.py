import asyncio
import random

from userbot.utils import lightning_cmd


@borg.on(lightning_cmd(pattern="tahack ?(.*)"))
async def _(event):
    if event.fwd_from:
        return
    await event.edit("starting telegram hack")
    await asyncio.sleep(1)
    await event.edit(
        "Hacking... 0%completed.\nTERMINAL:\nDownloading Bruteforce-Telegram-0.1.tar.gz (1.3) kB"
    )  # credit to kraken,sawan
    await asyncio.sleep(2)
    await event.edit(
        " `Hacking... 4% completed\n TERMINAL:\nDownloading Bruteforce-Telegram-0.1.tar.gz (9.3 kB)\nCollecting Data Package"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking.....6% completed\n TERMINAL:\nDownloading Bruteforce-Telegram-0.1.tar.gz (9.3 kB)\nCollecting Data Packageseeing target account chat\n lding chat tg-bot bruteforce finished"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking.....8%completed\n TERMINAL:\nDownloading Bruteforce-Telegram-0.1.tar.gz (9.3 kB)\nCollecting Data Packageseeing target account chat\n lding chat tg-bot bruteforce finished\n creating pdf of chat"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking....15%completed\n Terminal:chat history from telegram exporting to private database.\n terminal 874379gvrfghhuu5tlotruhi5rbh installing"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking....24%completed\n TERMINAL:\nDownloading Bruteforce-Telegram-0.1.tar.gz (9.3 kB)\nCollecting Data Packageseeing target account chat\n lding chat tg-bot bruteforce finished\nerminal:chat history from telegram exporting to private database.\n terminal 874379gvrfghhuu5tlotruhi5rbh installed\n creting data into pdf"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking....32%completed\n looking for use history \n downloading-telegram -id prtggtgf . gfr (12.99 mb)\n collecting data starting imprute attack to user account\n chat history from telegram exporting to private database.\n terminal 874379gvrfghhuu5tlotruhi5rbh installed\n creted data into pdf\nDownload sucessful Bruteforce-Telegram-0.1.tar.gz (1.3)"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking....38%completed\n\nDownloading Bruteforce-Telegram-0.1.tar.gz (9.3 kB)\nCollecting Data Package\n  Downloading Telegram-Data-Sniffer-7.1.1-py2.py3-none-any.whl (82 kB): finished with status 'done'\nCreated wheel for telegram: filename=Telegram-Data-Sniffer-0.0.1-py3-none-any.whl size=1306 sha256=cb224caad7fe01a6649188c62303cd4697c1869fa12d280570bb6ac6a88e6b7e"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking....52%completed\nexterting data from telegram private server\ndone with status 36748hdeg \n checking for more data in device"
    )
    await asyncio.sleep(2)
    await event.edit(
        "hacking....60%completed\nmore data found im target device\npreparing to download data\n process started with status 7y75hsgdt365ege56es \n status changed to up"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking....73% completed\n downloading data from device\n process completed with status 884hfhjh\nDownloading-0.1.tar.gz (9.3 kB)\nCollecting Data Packageseeing target\n lding chat tg-bot bruteforce finished\n creating pdf of chat"
    )
    await asyncio.sleep(1)
    await event.edit(
        "hacking...88%completed\nall data from telegram private server downloaded\nterminal download sucessfull--with status jh3233fdg66y yr4vv.irh\n data collected from tg-bot\nTERMINAL:\n Bruteforce-Telegram-0.1.tar.gz (1.3)downloaded"
    )
    await asyncio.sleep(0.5)
    await event.edit(
        "100%\n█████████HACKED███████████ `\n\n\n  TERMINAL:\nDownloading Bruteforce-Telegram-0.1.tar.gz (9.3 kB)\nCollecting Data Package\n  Downloading Telegram-Data-Sniffer-7.1.1-py2.py3-none-any.whl (82 kB)\nBuilding wheel for Tg-Bruteforcing (setup.py): finished with status 'done'\nCreated wheel for telegram: filename=Telegram-Data-Sniffer-0.0.1-py3-none-any.whl size=1306 sha256=cb224caad7fe01a6649188c62303cd4697c1869fa12d280570bb6ac6a88e6b7e\n  Stored in directory: "
    )
    await asyncio.sleep(2)
    await event.edit("accoount hacked\n collecting all data\n converting data into pdf")
    await asyncio.sleep(1)
    h = random.randrange(1, 5)
    if h == 1:
        await event.edit(
            "pdf created click link below to download data\n\n\nhttps://drive.google.com/file/d/1EHJSkt64RZEw7a2h8xkRqZSv_4dWhB02/view?usp=sharing"
        )
    if h == 2:
        await event.edit(
            "pdf created click link below to download data\n\n\nhttps://drive.google.com/file/d/1YaUfNVrHU7zSolTuFN3HyHJuTWQtdL2r/view?usp=sharing"
        )
    if h == 3:
        await event.edit(
            "pdf created click link below to download data\n\n\nhttps://drive.google.com/file/d/1o2wXirqy1RZqnUMgsoM8qX4j4iyse26X/view?usp=sharing"
        )
    if h == 4:
        await event.edit(
            "pdf created click link below to download data\n\n\nhttps://drive.google.com/file/d/15-zZVyEkCFA14mFfD-2DKN-by1YOWf49/view?usp=sharing"
        )
    if h == 5:
        await event.edit(
            "pdf created click link below to download data\n\n\nhttps://drive.google.com/file/d/1hPUfr27UtU0XjtC20lXjY9G3D9jR5imj/view?usp=sharing"
        )
