import os
os.system("git clone https://github.com/KeinShin/Black-Lightning /root/userbot && mkdir /root/userbot/bin/ && cd /root/userbot/ && chmod +x /usr/local/bin/* && python3 -m userbot")
