
<h2 align="center"><b>Owner: <a href="https://telegram.dog/krish1303y">KeinShin 🇮🇳</a></b></h2>
<br>
<p align="center"><a href="https://t.me/lightning_support_group"><img src="https://telegra.ph/file/07d55d71944a852ac6d5e.jpg"></a></p> 
</p>
<h1>BLACK LIGHTNING</h1>
<b>A Powerful, Smart And Simple Userbot In Telethon.</b>
<br>
<br>

[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.png?v=103)]( https://github.com/KeinShin/Black-Lightning)
[![GPLv3 license](https://img.shields.io/badge/License-GPLv3-blue.svg?&style=flat-square)]( https://github.com/KeinShin/Black-Lightning#copyright--license)
[![Stars](https://img.shields.io/github/stars/KeinShin/Black-Lightning?&style=flat-square)]( https://github.com/KeinShin/Black-Lightning/stargazers)
[![Forks](https://img.shields.io/github/forks/KeinShin/Black-Lightning?&style=flat-square)]( https://github.com/KeinShin/Black-Lightning/network/members)
[![Issues Open](https://img.shields.io/github/issues/KeinShin/Black-Lightning?&style=flat-square)]( https://github.com/KeinShin/Black-Lightning/issues)
[![Issues Closed](https://img.shields.io/github/issues-closed/KeinShin/Black-Lightning?&style=flat-square)]( https://github.com/KeinShin/Black-Lightning/issues?q=is:closed)
[![PR Open](https://img.shields.io/github/issues-pr/KeinShin/Black-Lightning?&style=flat-square)]( https://github.com/KeinShin/Black-Lightning/pulls)
[![PR Closed](https://img.shields.io/github/issues-pr-closed/KeinShin/Black-Lightning?&style=flat-square)]( https://github.com/KeinShin/Black-Lightning/pulls?q=is:closed)
![Repo Size](https://img.shields.io/github/repo-size/KeinShin/Black-Lightning?style=flat-square)
<br>


# Credits 
## This is A Remix Bot Of Many UserBot.
* [DARKCOBRA](https://github.com/DARK-COBRA/DARKCOBRA)
* [FridayUserBot](https://github.com/DevsExpo/FridayUserbot)
* [Jarvisuserbot](https://github.com/Jarvis-Works/JarvisUserbot)
* [Javes 2.0](https://github.com/Javes786/javes-2.0)
* [TeleBot](https://github.com/xditya/TeleBot)
* [Uniborg](https://github.com/SpEcHiDe/UniBorg)
* [CipherX](https://t.me/CipherXBot)
* [Hellboi-Danish](https://t.me/Hellboi-Danish)

# Special thanks
to [Aditya](https://github.com/Paramatin-OP) for maintaining the repository

# Support
<a href="https://t.me/Gflixofficial"><img src="https://img.shields.io/badge/Join-Support%20Channel-red.svg?style=for-the-badge&logo=Telegram"></a>

## Total Commands = CMDS Are More Than 470 :D
# About ɮʟǟƈᏦ ʟɨɢɦƭռɨռɢ

1. Can Do Many This Such As Download ANy Video From Youtube and Other Sites

2. Many Things For Adult Tho....

3. Many Cool CMDS To Trick Your Friends

4. Can Give Mast To Any Img Such As .Krish Mask,Gold Mask, ManyOther

5. And More CMDS Just Deploy It 

6. Can Spam Over 9999 Words And Can Spam Images And Medias

7. Its Has Many Plugins To Trick Your Friends 

8. Many  Animated Filters Plugins Like ```Rock``` ```Hello```  ```Heart```  ```Adults``` Filters Like ``Sax`` etc....

9. Can Tell You About The Person when he/she Will Enter In Ur Grup That He Is Spammer And Will Ban him/her automatically

10. Can Tell You Any State or COuntry Coivd Cases

11. Can Give u Cricket Scores (Credits Given In Plugins)

12. And If You Are Goinn To Sleep Do ```.night``` The Bot WIll Auto Reply Messages With A Good Night Message ( Some Thing Like Afk But Different)

13. Afk Feature When You Are Goin Offline

14. And If You Are Goinn For Study  Do ```.study``` The Bot WIll Auto Reply Messages With A Good Study Message ( Some Thing Like Afk But Different)

15. And 5 types Of Hack CMDs

16. And Many More CMDS 



## Note-: 

This is a userbot made for telegram. I made this userbot with help of all other userbots available in telegram. All credits goes to its Respective Owners.......

# Requirements 
* Python 3.8 or Higher
* Telegram [API Keys](https://my.telegram.org/apps)
* String [Gernate from here](https://repl.it/@Anmol10H/Lightning-Repl#main.py)


# How To

<a href="https://youtu.be/xfHcm_e92eQ"><img src="https://img.shields.io/badge/How%20To-Deploy-red.svg?logo=Youtube"></a>

<a href="https://app.gitbook.com/@poxsisofficial/s/blackBlack Lightning /"><img src="https://img.shields.io/badge/Read%20More-GitBook-red.svg"></a>

# Deploy

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/KeinShin/Black-Lightning)

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https%3A%2F%2Fgithub.com%2FKeinShin%2FBlack-Lightning&envs=ALIVE_NAME%2CAPP_ID%2CAPI_HASH%2CSTRING_SESSION%2CCOMBINED_GROUP_ID%2CTG_BOT_TOKEN_BF_HER%2CTG_BOT_USER_NAME_BF_HER&ALIVE_NAMEDesc=Ur+Telegram+username+with+starts+with+@&APP_IDDesc=Get+this+value+from+my.telegram.org%21+Please+do+not+steal&API_HASHDesc=Get+this+value+from+my.telegram.org%21+Please+do+not+steal&STRING_SESSIONDesc=Get+this+value+by+running+python3+telesetup.py+locally+or+https%3A%2F%2Freplit.com%2F%40Paramatin%2FLightning-Repl%23main.py+online.&COMBINED_GROUP_IDDesc=This+is+all+in+one+group+id.+just+add+%40Missrose_bot+to+your+private+group+and+do+%2Fid&TG_BOT_TOKEN_BF_HERDesc=Needed+for+inline+buttons+maker.+Make+a+bot+at+http%3A%2F%2Ftelegram.dog%2FBotFather+and+get+the+token+of+your+bot.+Get+it+else+.help+won%27t+work.&TG_BOT_USER_NAME_BF_HERDesc=Needed+for+inline+buttons+maker.+Make+a+bot+at+http%3A%2F%2Ftelegram.dog%2FBotFather+and+get+the+username+of+your+bot.+Get+it+else+.help+won%27t+work)

# String

[![Run on Repl.it](https://repl.it/badge/github/KeinShin/Black-Lightning&theme=midnight-purple)](https://replit.com/@Paramatin/Lightning-Repl#main.py
)

# The Normal Way

Simply clone the repository and run the main file:
```sh
git clone https://github/KeinShin/Black-Lightning.git
cd Black Lightning 
virtualenv -p /usr/bin/python3 venv
. ./venv/bin/activate
pip install -r requirements.txt
# <Create local_config.py with variables as given below>
python3 -m Black-Lightning
```




# Mandatory Vars
```
[+] Only two of the environment variables are mandatory.

[+] This is because of telethon.errors.rpc_error_list.ApiIdPublishedFloodError

    [-] APP_ID:   You can get this value from https://my.telegram.org
    [-] API_HASH :   You can get this value from https://my.telegram.org
    
[+] The Lightning Bot will not work without setting the mandatory vars.
```
